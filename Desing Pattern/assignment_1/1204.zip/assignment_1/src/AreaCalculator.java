class AreaCalculator {
    public void calculateArea(Shape s) {
        System.out.println(s.calculateArea());
    }
}
