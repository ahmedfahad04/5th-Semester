interface Shape {

    double calculateArea();

    void setTopLeft(double x, double y);

    void draw();

}
