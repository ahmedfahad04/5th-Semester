package com.singleton_pattern;

public interface Widgets {

    void setName();
    void setPosition();
    String getObjectName();
}
