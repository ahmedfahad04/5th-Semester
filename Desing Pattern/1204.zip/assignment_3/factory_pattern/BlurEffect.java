package com.factory_pattern;

public class BlurEffect extends GraphicEffect{

}
