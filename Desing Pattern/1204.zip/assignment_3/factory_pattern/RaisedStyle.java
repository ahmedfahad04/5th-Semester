package com.factory_pattern;

public class RaisedStyle extends StyleSheet{
}
