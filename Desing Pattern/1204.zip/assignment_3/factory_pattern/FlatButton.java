package com.factory_pattern;

import javax.swing.text.Style;

public class FlatButton extends Button{

    public FlatButton(String buttonLable) {
        super(buttonLable);
    }

    @Override
    public StyleSheet setStyle() {
        return new FlatStyle();
    }

    @Override
    public GraphicEffect setEffect() {
        return new BlurEffect();
    }
}
