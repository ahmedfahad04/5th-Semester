package com.factory_pattern;

public class GraphicEffect {
}
