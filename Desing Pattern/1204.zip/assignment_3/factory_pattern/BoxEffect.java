package com.factory_pattern;

public class BoxEffect extends GraphicEffect{
}
