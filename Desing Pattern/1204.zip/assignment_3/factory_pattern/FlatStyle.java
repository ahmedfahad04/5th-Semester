package com.factory_pattern;

public class FlatStyle extends StyleSheet{

}
