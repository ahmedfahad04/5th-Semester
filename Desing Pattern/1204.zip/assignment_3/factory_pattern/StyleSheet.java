package com.factory_pattern;

public class StyleSheet {

}
