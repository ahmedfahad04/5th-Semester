package ActualCode;

public class Document {

    public Document () {

    };
}
