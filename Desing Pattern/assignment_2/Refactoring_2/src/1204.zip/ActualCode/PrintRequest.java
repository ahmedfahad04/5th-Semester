package ActualCode;

public class PrintRequest {

    private Document document;
    private TonerSaveMode tonerSaveMode;
    private PageSaveMode pageSaveMode;
    private BoosterMode boosterMode;

}
