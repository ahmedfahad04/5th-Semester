package ActualCode;

public class PrioritySetting {

    public PrioritySetting () {};


}
