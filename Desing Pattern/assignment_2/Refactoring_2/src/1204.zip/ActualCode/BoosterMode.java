package ActualCode;

/*
The BoosterMode increases the color intensity up to a maximum acceptable level that is set via its intensityThreshold field.
 */
public class BoosterMode extends PrintMode {

    private String intensityThreshold;

    @Override
    public void saveToner() {

    }

    @Override
    public void savePage() {

    }

    @Override
    public void boost() {

    }
}
