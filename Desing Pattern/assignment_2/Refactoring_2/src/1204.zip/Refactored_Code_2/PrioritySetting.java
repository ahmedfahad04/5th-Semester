package Refactored_Code_2;

public class PrioritySetting {

    public PrioritySetting () {};

    private void changePriority(){
        System.out.println("Change priority of job");
    }

}
