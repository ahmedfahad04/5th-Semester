package Refactored_Code_2;


public class PrintRequest {

    private Document document;
    private TonerSaveMode tonerSaveMode;
    private PageSaveMode pageSaveMode;
    private BoosterMode boosterMode;


}
