package Refactored_Code_2;

public interface IColorIntensity {

    boolean matchColorIntensity(String tonerSavingLevel);
    String getColorIntensity();
}
