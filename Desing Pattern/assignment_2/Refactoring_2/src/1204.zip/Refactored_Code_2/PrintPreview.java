package Refactored_Code_2;

public class PrintPreview {

    private void renderPreview(){
        System.out.println("Shows preview of updated document");
    }

}
