package Refactored_Code_2;

public class Document {

    public int pageSize;
    public int numberOfPage;

    public Document () {};

}
